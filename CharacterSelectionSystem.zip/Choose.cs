using UnityEngine;

public class Choose : MonoBehaviour
{
    public GameObject[] characters;
    private int currentIndex = 0;

    void Start()
    {
        foreach (GameObject character in characters)
            character.SetActive(false);

        characters[currentIndex].SetActive(true);
    }

    public void Next()
    {
        characters[currentIndex].SetActive(false);
        currentIndex = (currentIndex + 1) % characters.Length;
        characters[currentIndex].SetActive(true);
    }

    public void Previous()
    {
        characters[currentIndex].SetActive(false);
        currentIndex = (currentIndex - 1 + characters.Length) % characters.Length;
        characters[currentIndex].SetActive(true);
    }

    public void Confirm()
    {
        PlayerPrefs.SetInt("SelectedCharacter", currentIndex);
        PlayerPrefs.Save();
        Debug.Log("Escolhido personagem: " + currentIndex);
        // SceneManager.LoadScene("GameScene");
    }
}
