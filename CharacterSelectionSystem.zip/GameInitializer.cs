using UnityEngine;

public class GameInitializer : MonoBehaviour
{
    public GameObject[] allCharacters;

    void Start()
    {
        int index = PlayerPrefs.GetInt("SelectedCharacter", 0);
        for (int i = 0; i < allCharacters.Length; i++)
        {
            allCharacters[i].SetActive(i == index);
        }
    }
}
