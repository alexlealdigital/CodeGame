using UnityEngine;

public class ControladorCor : MonoBehaviour
{
    public enum ParteVisual { Pele, Cabelo, Camisa, Calca }

    public ParteVisual parteAtual = ParteVisual.Pele;

    public Material materialPele;
    public Material materialCabelo;
    public Material materialCamisa;
    public Material materialCalca;

    public void TrocarParte(int index)
    {
        parteAtual = (ParteVisual)index;
        AplicarCorSalvaDaParteAtual();
    }

    public void AplicarCor(Color cor)
    {
        switch (parteAtual)
        {
            case ParteVisual.Pele:
                materialPele.color = cor;
                PlayerPrefs.SetString("CorPele", ColorUtility.ToHtmlStringRGBA(cor));
                break;
            case ParteVisual.Cabelo:
                materialCabelo.color = cor;
                PlayerPrefs.SetString("CorCabelo", ColorUtility.ToHtmlStringRGBA(cor));
                break;
            case ParteVisual.Camisa:
                materialCamisa.color = cor;
                PlayerPrefs.SetString("CorCamisa", ColorUtility.ToHtmlStringRGBA(cor));
                break;
            case ParteVisual.Calca:
                materialCalca.color = cor;
                PlayerPrefs.SetString("CorCalca", ColorUtility.ToHtmlStringRGBA(cor));
                break;
        }

        PlayerPrefs.Save();
    }

    public void AplicarCoresSalvas()
    {
        Color cor;

        if (ColorUtility.TryParseHtmlString("#" + PlayerPrefs.GetString("CorPele", "#FFFFFFFF"), out cor))
            materialPele.color = cor;

        if (ColorUtility.TryParseHtmlString("#" + PlayerPrefs.GetString("CorCabelo", "#FFFFFFFF"), out cor))
            materialCabelo.color = cor;

        if (ColorUtility.TryParseHtmlString("#" + PlayerPrefs.GetString("CorCamisa", "#FFFFFFFF"), out cor))
            materialCamisa.color = cor;

        if (ColorUtility.TryParseHtmlString("#" + PlayerPrefs.GetString("CorCalca", "#FFFFFFFF"), out cor))
            materialCalca.color = cor;
    }

    private void AplicarCorSalvaDaParteAtual()
    {
        string corSalva = null;
        switch (parteAtual)
        {
            case ParteVisual.Pele:
                corSalva = PlayerPrefs.GetString("CorPele", "#FFFFFFFF");
                break;
            case ParteVisual.Cabelo:
                corSalva = PlayerPrefs.GetString("CorCabelo", "#FFFFFFFF");
                break;
            case ParteVisual.Camisa:
                corSalva = PlayerPrefs.GetString("CorCamisa", "#FFFFFFFF");
                break;
            case ParteVisual.Calca:
                corSalva = PlayerPrefs.GetString("CorCalca", "#FFFFFFFF");
                break;
        }

        if (ColorUtility.TryParseHtmlString("#" + corSalva.TrimStart('#'), out Color cor))
        {
            AplicarCor(cor);
        }
    }
}
