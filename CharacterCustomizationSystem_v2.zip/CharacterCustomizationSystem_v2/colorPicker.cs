using UnityEngine;
using UnityEngine.UI;

public class colorPicker : MonoBehaviour
{
    RectTransform rect;
    Texture2D colorTexture;

    public ControladorCor controladorCor;

    void Start()
    {
        rect = GetComponent<RectTransform>();
        colorTexture = GetComponent<Image>().mainTexture as Texture2D;
    }

    void Update()
    {
        if (!RectTransformUtility.RectangleContainsScreenPoint(rect, Input.mousePosition))
            return; // ← se o clique estiver fora da imagem, sai

        Vector2 localPoint;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, Input.mousePosition, null, out localPoint);

        float width = rect.rect.width;
        float height = rect.rect.height;
        localPoint += new Vector2(width * 0.5f, height * 0.5f);

        float x = Mathf.Clamp01(localPoint.x / width);
        float y = Mathf.Clamp01(localPoint.y / height);

        int texX = Mathf.RoundToInt(x * colorTexture.width);
        int texY = Mathf.RoundToInt(y * colorTexture.height);

        Color color = colorTexture.GetPixel(texX, texY);

        if (Input.GetMouseButtonDown(0))
        {
            controladorCor.AplicarCor(color);
        }
    }
}
